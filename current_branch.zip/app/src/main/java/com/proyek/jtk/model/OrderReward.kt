package com.proyek.jtk.model

data class OrderReward(
    val reward: Reward,
    val count: Int
)